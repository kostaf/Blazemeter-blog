package com.wfsc.pki.util.Jmeter.Samplers;
  
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
  
public class OCSP_Sampler extends AbstractJavaSamplerClient {
  public SampleResult runTest(JavaSamplerContext context) {
    SampleResult results = new SampleResult();
    results.sampleStart();
    
    String EE_Certificate = context.getParameter("EE_Certificate");
    String CA_Certificate = context.getParameter("CA_Certificate");
    String OCSP_URL = context.getParameter("OCSP_URL");
    
    String[] argz = {EE_Certificate, CA_Certificate, OCSP_URL}; 
    boolean result = false;
    
	try {
		result = com.wfsc.pki.util.Jmeter.Samplers.OCSP_Request.main(argz);
		System.out.println("result: " + result);
	} catch (Exception e) {
		e.printStackTrace();
	}
    if (result == true) {
       results.setSuccessful(true);
       results.setResponseCodeOK();
       results.setResponseMessage("'myResult:" + result);
    } else {
       results.setSuccessful(false);
    }
    results.sampleEnd();
    return results;
  }
  
  @Override
  public Arguments getDefaultParameters() {
    Arguments args = new Arguments();
    args.addArgument("EE_Certificate", "./cert.cer");
    args.addArgument("CA_Certificate", "./ca.cer");
    args.addArgument("OCSP_URL", "http://localhost:80");
    return args;
  }
}