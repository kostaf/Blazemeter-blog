package com.wfsc.pki.util.Jmeter.Samplers;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import java.util.Vector;

import org.bouncycastle.asn1.DERObjectIdentifier;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.ocsp.OCSPObjectIdentifiers;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.ocsp.BasicOCSPResp;
import org.bouncycastle.ocsp.CertificateID;

import org.bouncycastle.ocsp.CertificateStatus;
import org.bouncycastle.ocsp.OCSPException;
import org.bouncycastle.ocsp.OCSPReq;
import org.bouncycastle.ocsp.OCSPReqGenerator;
import org.bouncycastle.ocsp.OCSPResp;
import org.bouncycastle.ocsp.SingleResp;

import sun.security.krb5.internal.crypto.Nonce;

public class OCSP_Request {

	private static OCSPReq generateOCSPRequest(X509Certificate issuerCert,
			BigInteger serialNumber) throws OCSPException {

		// Add provider BC
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

		// Generate the id for the certificate we are looking for
		CertificateID id = new CertificateID(CertificateID.HASH_SHA1,issuerCert, serialNumber);

		// basic request generation with nonce
		OCSPReqGenerator gen = new OCSPReqGenerator();

		gen.addRequest(id);

		// create details for nonce extension
		BigInteger nonce = BigInteger.valueOf(System.currentTimeMillis());
		Vector<DERObjectIdentifier> oids = new Vector<DERObjectIdentifier>();
		Vector<X509Extension> values = new Vector<X509Extension>();

		oids.add(OCSPObjectIdentifiers.id_pkix_ocsp_nonce);
		values.add(new X509Extension(false, new DEROctetString(nonce.toByteArray())));
		gen.setRequestExtensions(new X509Extensions(oids, values));
		System.out.println("Request nOnce value: " + values.get(0).getValue());
		return gen.generate();
	}

	public static boolean main(String[] args) throws Exception {
		
		/*
		 *  Read End-Entity Certificate
		 *  This is the certificate which we are checking the status of
		 */
		
		InputStream inStream = new FileInputStream(args[0]);
		CertificateFactory cf;

		cf = CertificateFactory.getInstance("X.509");

		X509Certificate interCert = (X509Certificate) cf.generateCertificate(inStream);
		inStream.close();

		// Read CA Certificate
		InputStream inStreamRoot = new FileInputStream(args[1]);
		X509Certificate rootCert = (X509Certificate) cf.generateCertificate(inStreamRoot);
		inStreamRoot.close();

		OCSPReq request1 = generateOCSPRequest(rootCert, interCert.getSerialNumber());

		byte[] array;

		array = request1.getEncoded();

		String serviceAddr = args[2];

		@SuppressWarnings("unused")
		String hostAddr = "";
		if (serviceAddr != null) {
			hostAddr = serviceAddr;
		}
		
			HttpURLConnection con = null;
			URL url = new URL(serviceAddr);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestProperty("Content-Type", "application/ocsp-request");
			con.setRequestProperty("Accept", "application/ocsp-response");
			con.setDoOutput(true);
			OutputStream out1 = con.getOutputStream();
			DataOutputStream dataOut = new DataOutputStream(new BufferedOutputStream(out1));

			try {
				dataOut.write(array);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			dataOut.flush();
			dataOut.close();

			// Check errors in response:
			if (con.getResponseCode() / 100 != 2) {
				throw new Exception("***Error***");
			}

			// Get Response
		    boolean responseBool = false;
			InputStream in = (InputStream) con.getContent();
			OCSPResp ocspResponse = new OCSPResp(in);

			BasicOCSPResp basicResponse = (BasicOCSPResp) ocspResponse.getResponseObject();
						
			if (basicResponse != null) {
				SingleResp[] responses = basicResponse.getResponses();
				
				System.out.println("Requesting Status For");
				System.out.println("Certificate Serial Number: " + interCert.getSerialNumber() + "\n");
				System.out.println("Certificate Subject: " + interCert.getSubjectDN());
				System.out.println("Issuing CA Subject: " + interCert.getIssuerDN() + "\n");
				System.out.println("timestamp for nOnce was: " + Nonce.value() + "\n");
				
				
				if (responses.length == 1) {
					SingleResp resp = responses[0];

					Object status = resp.getCertStatus();
					if (status == CertificateStatus.GOOD) {
						System.out.println("OCSP Status is good!");
						
					} else if (status instanceof org.bouncycastle.ocsp.RevokedStatus) {
						System.out.println("OCSP Status is revoked!");

					} else if (status instanceof org.bouncycastle.ocsp.UnknownStatus) {
						System.out.println("OCSP Status is unknown!");
					}
				}
				
				responseBool = true;	
			}

			return responseBool;	
		}
	}