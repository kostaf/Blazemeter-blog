import com.launchdarkly.eventsource.EventSource;
import com.launchdarkly.eventsource.EventHandler;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import java.io.StringReader;
import java.net.URI;
import java.util.concurrent.TimeUnit;

public class SSERequest {

    private String sURL = "";
    private Integer rTime = new Integer(0);
    private Integer sTime = new Integer(0);
    private String opt1 = "";
    private String opt2 = "";

    public String respList = "";

    SSERequest(String[] sseParameters){
        sURL = sseParameters[0];
        rTime = Integer.parseInt(sseParameters[1]);
        sTime = Integer.parseInt(sseParameters[2]);
        opt1 = sseParameters[3];
        opt2 = sseParameters[4];
    }

    public void makeRequest(String[] args) throws InterruptedException{
        EventHandler eventHandler = new SimpleEventHandler();
        String url = sURL;
        EventSource.Builder builder = new EventSource.Builder(eventHandler, URI.create(url));

        EventSource eventSource = builder.build();
        eventSource.setReconnectionTimeMs(rTime);
        eventSource.start();
        TimeUnit.SECONDS.sleep(sTime);
        eventSource.close();
        System.out.println("Filtered output: \n");

        for(String respRecord:((SimpleEventHandler) eventHandler).respList) {
            JsonReader jsonReader = Json.createReader(new StringReader(respRecord));
            JsonObject jsonObject = jsonReader.readObject();
            JsonValue title = jsonObject.getValue(opt1);
            JsonValue chType = jsonObject.getValue(opt2);
            respList = respList +chType.toString() + " : " + title.toString()+"\n";
        }
    }


}
