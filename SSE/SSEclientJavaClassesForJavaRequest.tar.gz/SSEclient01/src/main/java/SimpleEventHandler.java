import com.launchdarkly.eventsource.MessageEvent;
import com.launchdarkly.eventsource.EventHandler;
import java.util.ArrayList;

public class SimpleEventHandler implements EventHandler{
    public ArrayList<String> respList = new ArrayList<String>();

    @Override
    public void onOpen() throws Exception{
        System.out.println("The connection has been opened");
    }

    @Override
    public void onClosed() throws Exception{
        System.out.println("The connection has been closed");
    }

    @Override
    public void onMessage(String Event, MessageEvent messageEvent) throws Exception{
        respList.add(messageEvent.getData());
        System.out.println(messageEvent.getData());
    }

    @Override
    public void onComment(String comment) throws Exception{
        System.out.println(comment);
    }

    @Override
    public void onError(Throwable t ){
        System.out.println("Error "+t);
    }

}
