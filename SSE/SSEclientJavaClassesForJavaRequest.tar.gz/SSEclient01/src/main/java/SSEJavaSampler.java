import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

public class SSEJavaSampler extends AbstractJavaSamplerClient {
    @Override
    public void setupTest(JavaSamplerContext context){
        super.setupTest(context);
    }

    @Override
    public Arguments getDefaultParameters(){
        Arguments args = new Arguments();
        args.addArgument("serverURL", "${serverURL}");
        args.addArgument("reconnectionTime", "${reconnectionTime}");
        args.addArgument("sleepTime", "${sleepTime}");
        args.addArgument("option1", "${option1}");
        args.addArgument("option2","${option2}");
        return args;
    }

    @Override
    public SampleResult runTest(JavaSamplerContext jSC){

        SampleResult result = new SampleResult();
        boolean success = true;

        String[] sseParameters = new String[5];
        sseParameters[0] = jSC.getParameter("serverURL");
        sseParameters[1] = jSC.getParameter("reconnectionTime");
        sseParameters[2] = jSC.getParameter("sleepTime");
        sseParameters[3] = jSC.getParameter("option1");
        sseParameters[4] = jSC.getParameter("option2");

        SSERequest sseRequest = new SSERequest(sseParameters);

        result.sampleStart();
        result.sampleEnd();
        try {
            sseRequest.makeRequest(sseParameters);
            result.setSuccessful(success);
            result.setSamplerData(sseParameters[3]+":"+sseParameters[4]);
            result.setResponseData(sseRequest.respList,"866");
        }
        catch (InterruptedException iE){
            System.out.println("Interrupted exception " +iE);
        }
        return result;
    }

    @Override
    public void teardownTest(JavaSamplerContext context){
        super.teardownTest(context);

    }
}
